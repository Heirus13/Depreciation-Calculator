﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DepreciationCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Check if all required inputs are entered
            if (string.IsNullOrEmpty(InitialCosttextBox.Text) || string.IsNullOrEmpty(salvagetextBox.Text)
                || string.IsNullOrEmpty(lifeComboBox.Text))
            {
                MessageBox.Show("Please enter all required inputs!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Parse input values
            decimal cost, residualValue;
            int life;
            if (!decimal.TryParse(InitialCosttextBox.Text, out cost) || !decimal.TryParse(salvagetextBox.Text, out residualValue)
                || !int.TryParse((string)lifeComboBox.SelectedItem, out life))
            {
                MessageBox.Show("Invalid input values!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Calculate depreciation based on selected method
           
            decimal yearlyDepreciation = 0;
            listBox1.Items.Clear();

            if (sumButton.Checked)
            {
                yearlyDepreciation = SYD(cost, residualValue, life);          
            }
            else
            {
                yearlyDepreciation = SLN(cost, residualValue, life);
            }
        }

        private decimal SYD(decimal cost, decimal residualValue, int life)
        {
            decimal bookValue = cost;
            decimal sumOfYearDigits = 0;
            for (int year = 1; year <= life; year++)
            {
                sumOfYearDigits += life - year + 1;
            }
            decimal counter = life;
            decimal currentDepreciation = (counter / sumOfYearDigits) * (cost - residualValue);
            bookValue = cost - currentDepreciation;
            listBox1.Items.Add("Year \t Decepriation \t Book Value");

            for (int year = 1; year <= life; year++)
            {
                currentDepreciation = (counter / sumOfYearDigits) * (cost - residualValue);

                listBox1.Items.Add($"\n{year} \t {currentDepreciation:C2} \t\t {bookValue:C2}");

                counter--;
                bookValue = bookValue - currentDepreciation + 60;
            }

            return 0;
        }

        private decimal SLN(decimal cost, decimal residualValue, int life)
        {
            decimal bookValue = cost;
            decimal sumOfYearDigits = 0;
            for (int year = 1; year <= life; year++)
            {
                sumOfYearDigits += life - year + 1;
            }


            decimal counter = life;
            decimal currentDepreciation = (cost - residualValue) / life;
            bookValue = cost - currentDepreciation;
            listBox1.Items.Add("Year \t Decepriation \t Book Value");

            for (int year = 1; year <= life; year++)
            {
                currentDepreciation = (cost - residualValue) / life;

                listBox1.Items.Add($"\n{year} \t {currentDepreciation:C2} \t\t {bookValue:C2}");

                counter--;
                bookValue = bookValue - currentDepreciation;
            }

            return 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
